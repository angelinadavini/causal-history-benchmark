# Secondary amendment preflight record v2.1

Tokenizer-only job `6a90c6fa984507d9db4e91a7` used Transformers 5.13.0 and SentencePiece 0.2.1. It loaded no language-model weights and generated no acquisition-route result.

The job tested `Answer:`, `Answer: `, `Answer:\n`, `Answer = `, and `Answer =\n` across:

- Qwen revision `aa8e72537993ba99e69dfaafa59ed015b17504d1`;
- Mistral revision `c170c708c41dac9275d15a8fff4eca08d52bab71`;
- SAME/DIFFERENT and DAX/WUG;
- both content modes;
- both later-event values;
- every answer label `0/1/X/Y`.

`Answer:\n` and `Answer =\n` passed every prefix and non-empty-suffix check. `Answer:\n` was selected because it changes the failed query by one newline and preserves the existing answer label.

The amended runner is restricted to `qwen_secondary` at argument parsing.
