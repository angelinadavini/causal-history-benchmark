# Confirmatory secondary amendment v2.1

Read in this order:

1. `SECONDARY_AMENDMENT_PROTOCOL_v2_1.md`
2. `PREFLIGHT_RECORD_v2_1.md`
3. `BASE_V2_PROTOCOL.md`
4. `confirmatory_secondary_runner_v2_1.py`
5. `analyse_confirmatory_v2_1.py`
6. `BASE_V2_SEED_MANIFEST.json`
7. `CONFIRMATORY_SECONDARY_SEED_MANIFEST_v2_1.json` after freezing

The completed Qwen primary and Mistral replication outputs remain sealed under v2. This package repairs and reruns only the failed DAX/WUG secondary arm.
