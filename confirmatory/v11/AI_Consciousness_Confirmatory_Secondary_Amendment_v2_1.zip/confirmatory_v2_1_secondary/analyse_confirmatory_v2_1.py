#!/usr/bin/env python3
"""Prespecified joint analysis for sealed v2 arms and the v2.1 secondary amendment."""

from __future__ import annotations

import argparse
import base64
import gzip
import json
from pathlib import Path

import numpy as np


EPISODE_PREFIX = "CONFIRMATORY_EPISODE_JSON="
METADATA_PREFIX = "CONFIRMATORY_METADATA_JSON="
CHUNK_PREFIX = "CONFIRMATORY_RECORDS_CHUNK="


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("logs", nargs="+", type=Path)
    parser.add_argument("--base-seed-manifest", type=Path, required=True)
    parser.add_argument("--secondary-seed-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def load_logs(paths: list[Path]) -> tuple[dict[str, dict], dict[str, list[dict]]]:
    metadata: dict[str, dict] = {}
    records: dict[str, list[dict]] = {}
    for path in paths:
        chunks: dict[int, str] = {}
        chunk_total: int | None = None
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.startswith(METADATA_PREFIX):
                item = json.loads(line[len(METADATA_PREFIX) :])
                metadata[item["arm"]] = item
            elif line.startswith(EPISODE_PREFIX):
                item = json.loads(line[len(EPISODE_PREFIX) :])
                records.setdefault(item["arm"], []).append(item)
            elif line.startswith(CHUNK_PREFIX):
                header, payload = line[len(CHUNK_PREFIX) :].split(":", 1)
                index_text, total_text = header.split("/", 1)
                index = int(index_text)
                total = int(total_text)
                if chunk_total is not None and total != chunk_total:
                    raise RuntimeError(f"{path}: inconsistent record-chunk totals")
                chunk_total = total
                chunks[index] = payload
        if chunks:
            if chunk_total is None or sorted(chunks) != list(range(1, chunk_total + 1)):
                raise RuntimeError(f"{path}: incomplete packed record bundle")
            packed = "".join(chunks[index] for index in range(1, chunk_total + 1))
            bundled = json.loads(gzip.decompress(base64.b64decode(packed)).decode("utf-8"))
            if not bundled:
                raise RuntimeError(f"{path}: empty packed record bundle")
            arm = bundled[0]["arm"]
            if any(item["arm"] != arm for item in bundled):
                raise RuntimeError(f"{path}: packed record bundle contains multiple arms")
            records[arm] = bundled
    return metadata, records


def stratified_bootstrap(
    values: np.ndarray,
    strata: np.ndarray,
    rng: np.random.Generator,
    draws: int = 10_000,
) -> np.ndarray:
    unique = sorted(set(strata.tolist()))
    total = np.zeros(draws, dtype=np.float64)
    count = 0
    for stratum in unique:
        indices = np.flatnonzero(strata == stratum)
        sampled = rng.choice(indices, size=(draws, len(indices)), replace=True)
        total += values[sampled].sum(axis=1)
        count += len(indices)
    return total / count


def sign_flip_p(
    values: np.ndarray,
    rng: np.random.Generator,
    draws: int = 100_000,
) -> float:
    observed = abs(float(values.mean()))
    exceed = 0
    completed = 0
    chunk = 1_000
    while completed < draws:
        size = min(chunk, draws - completed)
        signs = rng.choice(np.array([-1.0, 1.0]), size=(size, len(values)))
        simulated = np.abs((signs * values).mean(axis=1))
        exceed += int(np.count_nonzero(simulated >= observed))
        completed += size
    return (exceed + 1) / (draws + 1)


def describe(
    values: np.ndarray,
    strata: np.ndarray,
    bootstrap_rng: np.random.Generator,
    randomisation_rng: np.random.Generator,
) -> dict:
    if not np.all(np.isfinite(values)):
        raise RuntimeError("non-finite confirmatory values")
    boot = stratified_bootstrap(values, strata, bootstrap_rng)
    return {
        "n": int(len(values)),
        "mean": float(values.mean()),
        "median": float(np.median(values)),
        "sd": float(values.std(ddof=1)),
        "ci95": [float(np.quantile(boot, 0.025)), float(np.quantile(boot, 0.975))],
        "ci90": [float(np.quantile(boot, 0.05)), float(np.quantile(boot, 0.95))],
        "positive_fraction": float(np.mean(values > 0)),
        "sign_flip_p_two_sided": sign_flip_p(values, randomisation_rng),
    }


def analyse_arm(arm: str, rows: list[dict], seeds: dict[str, int]) -> dict:
    rows = sorted(rows, key=lambda row: row["episode_id"])
    expected = {"qwen_primary": 512, "mistral_replication": 256, "qwen_secondary": 256}[arm]
    if len(rows) != expected:
        raise RuntimeError(f"{arm}: expected {expected} episodes, found {len(rows)}")
    ids = [row["episode_id"] for row in rows]
    if ids != list(range(expected)):
        raise RuntimeError(f"{arm}: episode IDs are incomplete or duplicated")

    strata = np.array([2 * int(row["mode"]) + int(row["event"]) for row in rows])
    bootstrap_rng = np.random.default_rng(int(seeds["bootstrap_seed"]))
    randomisation_rng = np.random.default_rng(int(seeds["randomisation_seed"]))

    def vector(key: str) -> np.ndarray:
        return np.array([float(row[key]) for row in rows], dtype=np.float64)

    hidden_route = vector("hidden_route_distance")
    logit_route = vector("logit_route_distance")
    if np.any(hidden_route <= 1e-12) or np.any(logit_route <= 1e-12):
        raise RuntimeError(f"{arm}: zero-length baseline route axis")

    outcomes = {
        "net_hidden": describe(vector("net_hidden"), strata, bootstrap_rng, randomisation_rng),
        "net_logit": describe(vector("net_logit"), strata, bootstrap_rng, randomisation_rng),
        "hidden_cut_ratio": describe(
            vector("hidden_cut_distance") / hidden_route,
            strata,
            bootstrap_rng,
            randomisation_rng,
        ),
        "logit_cut_ratio": describe(
            vector("logit_cut_distance") / logit_route,
            strata,
            bootstrap_rng,
            randomisation_rng,
        ),
        "margin_move_toward_donor": describe(
            vector("margin_move_toward_donor"),
            strata,
            bootstrap_rng,
            randomisation_rng,
        ),
        "probability_move_toward_donor": describe(
            vector("probability_move_toward_donor"),
            strata,
            bootstrap_rng,
            randomisation_rng,
        ),
    }
    if "cross_content_baseline_accuracy" in rows[0]:
        outcomes["cross_content_baseline_accuracy"] = describe(
            vector("cross_content_baseline_accuracy"),
            strata,
            bootstrap_rng,
            randomisation_rng,
        )
        outcomes["cross_content_donor_accuracy"] = describe(
            vector("cross_content_donor_accuracy"),
            strata,
            bootstrap_rng,
            randomisation_rng,
        )

    interval_hidden = outcomes["net_hidden"]["ci95"]
    interval_logit = outcomes["net_logit"]["ci95"]
    causal_success = interval_hidden[0] > 0 and interval_logit[0] > 0
    necessity_success = (
        outcomes["hidden_cut_ratio"]["ci95"][1] < 1
        and outcomes["logit_cut_ratio"]["ci95"][1] < 1
    )
    margin_ci90 = outcomes["margin_move_toward_donor"]["ci90"]
    probability_ci90 = outcomes["probability_move_toward_donor"]["ci90"]
    answer_equivalence = (
        margin_ci90[0] > -0.20
        and margin_ci90[1] < 0.20
        and probability_ci90[0] > -0.05
        and probability_ci90[1] < 0.05
    )
    return {
        "arm": arm,
        "outcomes": outcomes,
        "causal_route_axis_success": causal_success,
        "bridge_path_necessity_success": necessity_success,
        "answer_endpoint_equivalent_within_bounds": answer_equivalence,
    }


def main() -> None:
    args = parse_args()
    base_manifest = json.loads(args.base_seed_manifest.read_text(encoding="utf-8"))
    secondary_manifest = json.loads(
        args.secondary_seed_manifest.read_text(encoding="utf-8")
    )
    metadata, records = load_logs(args.logs)
    expected_arms = {"qwen_primary", "mistral_replication", "qwen_secondary"}
    missing = sorted(expected_arms - set(records))
    if missing:
        raise RuntimeError(f"missing confirmatory arms: {missing}")

    missing_metadata = sorted(expected_arms - set(metadata))
    if missing_metadata:
        raise RuntimeError(f"missing confirmatory metadata: {missing_metadata}")

    for arm in ("qwen_primary", "mistral_replication"):
        item = metadata[arm]
        for field in ("seed_manifest_sha256", "protocol_sha256", "runner_sha256"):
            expected_field = {
                "seed_manifest_sha256": "manifest_sha256",
                "protocol_sha256": "protocol_sha256",
                "runner_sha256": "runner_sha256",
            }[field]
            if item[field] != base_manifest[expected_field]:
                raise RuntimeError(f"{arm}: {field} does not match the sealed v2 lock")

    secondary_metadata = metadata["qwen_secondary"]
    for field in ("seed_manifest_sha256", "protocol_sha256", "runner_sha256"):
        expected_field = {
            "seed_manifest_sha256": "manifest_sha256",
            "protocol_sha256": "protocol_sha256",
            "runner_sha256": "runner_sha256",
        }[field]
        if secondary_metadata[field] != secondary_manifest[expected_field]:
            raise RuntimeError(f"qwen_secondary: {field} does not match the v2.1 lock")

    seeds = {
        "qwen_primary": base_manifest["arms"]["qwen_primary"],
        "mistral_replication": base_manifest["arms"]["mistral_replication"],
        "qwen_secondary": secondary_manifest["arms"]["qwen_secondary"],
    }

    result = {
        "base_v2_lock": {
            "protocol_sha256": base_manifest["protocol_sha256"],
            "runner_sha256": base_manifest["runner_sha256"],
            "seed_manifest_sha256": base_manifest["manifest_sha256"],
        },
        "secondary_v2_1_lock": {
            "protocol_sha256": secondary_manifest["protocol_sha256"],
            "runner_sha256": secondary_manifest["runner_sha256"],
            "analysis_sha256": secondary_manifest["analysis_sha256"],
            "seed_manifest_sha256": secondary_manifest["manifest_sha256"],
        },
        "metadata": metadata,
        "arms": {
            arm: analyse_arm(arm, records[arm], seeds[arm])
            for arm in ("qwen_primary", "mistral_replication", "qwen_secondary")
        },
    }
    result["primary_claim_passed"] = result["arms"]["qwen_primary"][
        "causal_route_axis_success"
    ]
    result["cross_model_replication_passed"] = result["arms"][
        "mistral_replication"
    ]["causal_route_axis_success"]
    result["secondary_task_replication_passed"] = result["arms"][
        "qwen_secondary"
    ]["causal_route_axis_success"]

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
