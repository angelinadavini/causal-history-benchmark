#!/usr/bin/env python3
"""Hash the secondary amendment, then create its one fresh seed manifest."""

from __future__ import annotations

import hashlib
import json
import secrets
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
FILES = {
    "protocol_sha256": ROOT / "SECONDARY_AMENDMENT_PROTOCOL_v2_1.md",
    "runner_sha256": ROOT / "confirmatory_secondary_runner_v2_1.py",
    "analysis_sha256": ROOT / "analyse_confirmatory_v2_1.py",
    "requirements_sha256": ROOT / "requirements-confirmatory.txt",
    "base_manifest_file_sha256": ROOT / "BASE_V2_SEED_MANIFEST.json",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_bytes(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")


def main() -> None:
    output = ROOT / "CONFIRMATORY_SECONDARY_SEED_MANIFEST_v2_1.json"
    if output.exists():
        raise RuntimeError(f"refusing to replace existing seed manifest: {output}")

    base_manifest = json.loads(
        (ROOT / "BASE_V2_SEED_MANIFEST.json").read_text(encoding="utf-8")
    )
    if base_manifest["manifest_sha256"] != (
        "fb42c0f7e984c8e775b55960eb5c7f9be02d6eff8944bcdb198223435764a7d2"
    ):
        raise RuntimeError("base v2 manifest lock does not match the sealed jobs")

    payload = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "entropy_source": "Python secrets.randbits using operating-system entropy",
        "base_v2_manifest_sha256": base_manifest["manifest_sha256"],
        "sealed_v2_jobs": {
            "qwen_primary": "6a90939f45686a1580c0f60e",
            "mistral_replication": "6a9093b3984507d9db4e8d7d",
        },
        "invalid_secondary_job": "6a90938c45686a1580c0f60c",
        **{field: sha256(path) for field, path in FILES.items()},
        "arms": {
            "qwen_secondary": {
                "episode_seed": secrets.randbits(63),
                "reference_seed": secrets.randbits(63),
                "bootstrap_seed": secrets.randbits(63),
                "randomisation_seed": secrets.randbits(63),
            }
        },
    }
    payload["manifest_sha256"] = hashlib.sha256(canonical_bytes(payload)).hexdigest()
    output.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(output)
    print(json.dumps({key: payload[key] for key in FILES}, indent=2, sort_keys=True))
    print("manifest_sha256", payload["manifest_sha256"])


if __name__ == "__main__":
    main()
