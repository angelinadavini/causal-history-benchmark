# Confirmatory secondary-arm amendment v2.1

Date frozen: 28 August 2026

## Status

This amendment repairs one tokenizer boundary in the DAX/WUG secondary arm before any completed confirmatory scientific output is opened.

The Qwen primary job `6a90939f45686a1580c0f60e` and Mistral replication job `6a9093b3984507d9db4e8d7d` completed under the original v2 lock. Their scientific logs remain unopened. Their code, seeds, endpoints, and decision rules remain fixed.

The Qwen DAX/WUG job `6a90938c45686a1580c0f60c` stopped on its first episode before emitting an episode record. It is excluded as an engineering failure.

## Failure

The v2 DAX/WUG query ended with `Answer:`. At the pinned Qwen tokenizer revision, appending `X` changed the tokenisation of the query boundary. The runner detected that the fixed query tokens were no longer an exact prefix and stopped.

The earlier contextual preflight covered the `0/1` labels used by SAME/DIFFERENT. It did not cover the `X/Y` labels used by DAX/WUG.

## Repair

The DAX/WUG query now ends with:

`Reply only X or Y.\nAnswer:\n`

Tokenizer-only job `6a90c6fa984507d9db4e91a7` tested five candidate endings across both pinned tokenizers, both tasks, both content modes, and both later-event values. `Answer:\n` preserved the complete query token sequence as an exact prefix for every `0/1/X/Y` candidate.

At the pinned Qwen revision, the contextual DAX/WUG suffixes are:

- `X`: token `[55]`;
- `Y`: token `[56]`.

At the pinned Mistral revision, they are:

- `X`: token `[29582]`;
- `Y`: token `[29570]`.

The Mistral values are retained as a cross-tokenizer engineering check. The amended secondary arm uses Qwen.

## Fixed scientific design

The model, revision, float16 format, DAX/WUG acquisition histories, template 3 evaluation wording, neutralised source prefix, five-token bridge, intervention layers 0–5, hidden-state layer 8, 256 balanced episodes, same-route controls, cross-route interchange, bridge cut, primary route-axis outcomes, supporting answer endpoints, bootstrap, sign-flip test, equivalence bounds, and decision rules remain unchanged.

Only the answer boundary gains a newline. New episode and analysis seeds are generated after the amended runner, protocol, and joint analysis are hashed.

## Joint analysis lock

The joint analysis accepts:

- the sealed Qwen primary and Mistral replication records under v2 manifest lock `fb42c0f7e984c8e775b55960eb5c7f9be02d6eff8944bcdb198223435764a7d2`;
- the fresh DAX/WUG records under this amendment lock.

It verifies the manifest, protocol, and runner hashes recorded in each arm's metadata before computing any outcome.

## Disconfirmation

The DAX/WUG replication fails if either prespecified route-axis confidence interval includes zero or lies below zero. A runtime, tokenisation, cache, or non-finite-output error remains an engineering failure.

## Limits

The experiment tests whether acquisition route leaves a causal state that changes later machine processing after source neutralisation and current-content resupply. It does not test phenomenal experience or establish consciousness.
