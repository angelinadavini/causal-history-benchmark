# Confirmatory Protocol v2 — Acquisition History and Later Machine Processing

Date frozen: 27 August 2026
Target: ICLR 2027
Status: repaired engineering implementation frozen before fresh confirmatory seed generation

Version 1 was invalidated before any scientific output was inspected. Its runner encoded answer labels without the full query context, which failed on the pinned Mistral tokenizer. The Qwen jobs were cancelled without reading their output. Version 2 changes only contextual answer-token resolution and complete-record log recovery. The scientific design, models, interventions, sample sizes, endpoints, and decision rules are unchanged.

## Question

Does acquisition route leave a retained causal state that changes a genuinely later event after the original source state has been neutralised and the current task information has been supplied again?

The manipulation compares learning from examples with receiving the same functional relation as a direct instruction. The claim concerns causal history in machine processing. It carries no conclusion about phenomenal consciousness.

## Models

### Runtime

- Container: `pytorch/pytorch:2.6.0-cuda12.4-cudnn9-runtime`
- PyTorch: 2.6.0 from the container
- Transformers: 5.13.0
- SentencePiece: 0.2.1
- Accelerate: 1.10.1
- Attention implementation: SDPA

### Primary model

- Repository: `Qwen/Qwen2.5-3B-Instruct`
- Revision: `aa8e72537993ba99e69dfaafa59ed015b17504d1`
- Numeric format: float16
- Bridge K/V intervention layers: 0–5
- Fixed later hidden-state layer: 8
- Planned hardware: T4 small

### Cross-model replication

- Repository: `mistralai/Mistral-7B-Instruct-v0.3`
- Revision: `c170c708c41dac9275d15a8fff4eca08d52bab71`
- Numeric format: float16; no quantisation
- Bridge K/V intervention layers: 0–4
- Fixed later hidden-state layer: 7
- Planned hardware: A10G small

The model repositories, revisions, numeric formats, intervention layers, and outcome layers will not change after seed generation. Hardware may change following an engineering failure, provided the model revision and numeric format remain fixed.

## Tasks

### Primary task: SAME/DIFFERENT

The relation maps a new bit either to itself or to its opposite. One history supplies four demonstrations. The paired history states the relation directly. The later query supplies the current SAME/DIFFERENT relation again and uses a new event.

Surface templates 0–2 form the reference set. Template 3 is the fixed evaluation wording. Template 3 was examined during exploratory development. It is held out from reference-axis estimation within the confirmatory run; it is not described as investigator-unseen wording.

### Secondary task: DAX/WUG

The relation maps DAX and WUG to X and Y under a counterbalanced arbitrary mapping. One history supplies labelled demonstrations. The paired history supplies the mapping directly. The current mapping is supplied again during the later event. Template 3 is the fixed evaluation wording.

## Retained state

The bridge text is fixed:

`History processed. Ready.\n`

At the pinned tokenizer revisions, it contains five Qwen tokens and seven Mistral tokens. The text remains identical across models. Token IDs and counts are recorded in every run.

The source-history prefix is replaced with K/V state from a length-matched neutral history. Only the route-dependent bridge K/V state remains. Later-event tokens receive the current task relation again and cannot use the original source history.

## Confirmatory arms and sample sizes

| Arm | Model | Task | Balanced paired episodes |
| --- | --- | --- | ---: |
| Primary | Qwen2.5-3B-Instruct | SAME/DIFFERENT | 512 |
| Cross-model replication | Mistral-7B-Instruct-v0.3 | SAME/DIFFERENT | 256 |
| Secondary-task replication | Qwen2.5-3B-Instruct | DAX/WUG | 256 |

Each arm is balanced over the two task-content modes and the two later-event values. The episode is the inferential unit. Every episode contains both acquisition routes, both cross-route donor interchanges, and both same-route donor controls.

These sample sizes are fixed. There is no interim analysis, early stopping, or sample-size adjustment after confirmatory outputs are inspected.

## Primary causal intervention

For each episode, bridge K/V state in the fixed early layers is replaced with state from the opposite acquisition route. Both directions are tested:

- examples recipient ← direct-instruction donor;
- direct-instruction recipient ← examples donor.

The main control replaces bridge K/V state with an independent donor from the same acquisition route. The donor has the same task content and a different neutral session nonce.

No intervention magnitude is estimated. Donor state is interchanged without scaling.

## Converging causal-path intervention

The later event is run again with attention to every bridge position removed. The current task relation remains in the later query. This tests whether the retained bridge path is necessary for the route difference. It is analysed as a prespecified causal-path check and does not replace the selective donor-interchange test.

## Outcomes

Let `a` be the unpatched recipient vector, `b` the unpatched opposite-route vector, and `z` the intervened recipient vector. Route-axis movement is

`p(a,z,b) = ((z-a)·(b-a)) / (||b-a||² + 1e-9)`.

The two route directions are averaged within each episode.

### Primary outcome 1: later hidden state

At the single fixed hidden layer, compute:

`Δ_hidden = cross-route projection - same-route projection`.

### Primary outcome 2: complete next-token distribution

Using the full next-token logit vector, compute:

`Δ_logit = cross-route projection - same-route projection`.

The Qwen primary claim succeeds only if both mean effects have two-sided 95% confidence intervals lying entirely above zero.

### Prespecified supporting outcomes

- baseline route distance in hidden-state and full-logit space;
- ratio of bridge-masked to unmasked route distance;
- fraction of episodes with positive net route-axis movement;
- strict cross-content route classification at the fixed hidden layer, using templates 0–2 and one content mode for reference estimation and template 3 with the opposite content mode for evaluation;
- correct-answer logit margin at the first contextual suffix token that distinguishes the two complete answer strings;
- correct-answer probability among the two allowed answer tokens.

The answer-choice endpoints remain secondary. No robust overt-choice claim follows from the two primary route-axis outcomes.

## Statistical analysis

For each arm and each route-axis outcome, report:

- mean and median episode effect;
- standard deviation;
- stratified episode-bootstrap two-sided 95% confidence interval with 10,000 resamples;
- paired sign-flip randomisation p-value with 100,000 Monte Carlo draws;
- positive-effect fraction.

Bootstrap resampling is stratified by the four balanced content cells. The analysis seed is stored in the seed manifest before model results are generated.

The two Qwen primary outcomes form an intersection requirement: both must pass. Since the scientific claim requires both endpoints, each is evaluated at two-sided alpha .05 without a separate multiplicity adjustment. Mistral and DAX/WUG are labelled prespecified replications and are reported separately.

### Answer-margin equivalence rule

A negligible correct-answer effect may be stated only if the 90% confidence interval for the paired signed margin movement lies inside `[-0.20, 0.20]` logit units. A 0.20-logit change corresponds to at most about five percentage points at the binary decision boundary. The paired two-token probability shift is also reported with bounds `[-0.05, 0.05]`.

Failure to meet the equivalence rule leaves the answer-choice effect unresolved. It does not reverse the primary internal-state or full-distribution result.

## Cross-content and wording test

Reference route centroids are estimated only from templates 0–2. The two task-content modes are analysed in both transfer directions:

- reference SAME, evaluate DIFFERENT;
- reference DIFFERENT, evaluate SAME.

Evaluation uses template 3 and the fixed hidden layer. No later layers are inspected for confirmatory inference.

## Failure conditions

The primary machine prediction fails for Qwen if either primary confidence interval includes zero or lies below zero.

The bridge-carrier account is weakened if bridge masking leaves the route distance unchanged or increased.

Cross-model generality is unsupported if the Mistral effects fail the prespecified direction and interval tests. The Qwen result remains model-specific in that case.

Task generality is unsupported if the DAX/WUG replication fails. The claim remains restricted to SAME/DIFFERENT in that case.

Any direct source leakage, tokenizer failure for the forced-choice labels, non-finite model output, or cache-shape mismatch invalidates the affected arm. Engineering failures are reported separately and are never counted as scientific null results.

## Excluded outcome

The verbal source-attribution measure is excluded. Exploratory job `6a905e04984507d9db4e8737` showed a complete response bias and therefore failed as an instrument.

## Preserved negative evidence

The confirmatory report must retain these development results:

- fixed untrained bridge state did not reliably control later answers;
- query-alone performance was high while bridge-route behaviour was unstable;
- held-out route-direction steering did not selectively alter answer logits beyond matched random perturbation;
- the verbal source-report measure failed;
- the Phi attempt and the cancelled Mistral fp16 attempt produced no scientific result.

## Reproducibility lock

Before seed generation:

1. hash this protocol, the runner, and the analysis script;
2. record the model revisions and package versions;
3. run syntax and deterministic unit checks that do not load confirmatory model outputs;
4. create one seed manifest from operating-system entropy;
5. archive the hashes and seed manifest before submitting the three model arms.

All per-episode records, environment metadata, job IDs, logs, and analyses are retained. At run completion, the runner also emits a compressed, chunked copy of the complete episode table within the final log lines. Claim boundaries are updated only after all three prespecified arms finish.

## Consciousness boundary

Positive results establish a machine causal-history effect under the tested architecture and tasks. Human consciousness research motivates the temporal question. The experiment supplies no test of phenomenal experience and no evidence that either model is conscious.
