# Claim boundaries after confirmatory v2.1

## Supported

The confirmatory evidence supports this claim:

> In Qwen2.5-3B-Instruct, acquisition route left a retained bridge state after source-history neutralisation. Exchanging early bridge K/V between acquisition routes causally moved both a fixed later hidden state and the complete next-token logit vector toward the donor history after the current task relation was supplied again. The effect replicated in Mistral-7B-Instruct-v0.3 and in a separate DAX/WUG mapping task.

The bridge-path intervention supports a carrier claim within this implementation: the measured route difference disappeared when later tokens could not attend to the bridge.

The SAME/DIFFERENT results also support cross-content and cross-wording transfer at the fixed hidden layer. Evaluation wording was held out from reference-centroid estimation. It was seen during exploratory development.

## Unsupported

Do not claim:

- consciousness, sentience, phenomenal experience, or subjective continuity;
- a unique criterion for consciousness;
- a general result for language models or artificial systems;
- a robust overt-choice effect;
- valid verbal source attribution;
- equivalence of the machine bridge state to human experience;
- investigator-unseen wording;
- independence from transformer K/V architecture;
- persistence over unrestricted delays or intervening events.

## Answer endpoint

The Qwen primary two-token probability movement was small. The signed correct-answer margin movement was 0.45166 logits with a 90% confidence interval of [0.43629, 0.46694], outside the prespecified equivalence bound. State only that the full distribution moved and that the secondary Qwen margin endpoint was not negligible under the frozen rule.

Mistral and DAX/WUG met both answer-endpoint equivalence bounds. The DAX/WUG movement was slightly opposite to the donor-defined answer direction.

## Nearest-prior-work boundary

The result does not claim discovery of KV leakage, generic history effects, decodability, task vectors, machine introspection, source-provenance signatures, temporal-continuity proposals, or the application of consciousness theories to AI indicators.

The contribution is the controlled causal sequence: same usable relation acquired through different routes → source prefix neutralised → current relation supplied again → early bridge K/V interchanged → genuinely later hidden state and complete logit distribution move toward donor history → bridge access removed and route difference disappears.
