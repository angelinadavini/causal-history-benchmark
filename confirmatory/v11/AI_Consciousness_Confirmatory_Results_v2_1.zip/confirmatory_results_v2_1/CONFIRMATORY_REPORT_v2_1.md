# Confirmatory report v2.1 — acquisition history and later machine processing

Date: 28 August 2026

## Result

The confirmatory prediction passed in the primary Qwen arm. It also passed in the prespecified Mistral replication and the DAX/WUG task replication.

Across all three arms, replacing early bridge K/V state with state from the opposite acquisition route moved the later hidden state and the complete next-token logit vector toward the donor history. Same-route donor interchange was subtracted from each effect. Removing attention to the bridge eliminated the measured route distance.

## Frozen design

The source-history prefix was replaced with state from a neutral history. The current task relation was supplied again during the later event. Acquisition route remained only in the bridge state. The intervention exchanged early bridge K/V between example-acquired and directly instructed histories.

The inferential unit was the balanced paired episode:

| Arm | Model | Task | Episodes |
| --- | --- | --- | ---: |
| Primary | Qwen2.5-3B-Instruct | SAME/DIFFERENT | 512 |
| Cross-model replication | Mistral-7B-Instruct-v0.3 | SAME/DIFFERENT | 256 |
| Secondary-task replication | Qwen2.5-3B-Instruct | DAX/WUG | 256 |

The Qwen primary claim required both route-axis outcomes to have two-sided 95% confidence intervals above zero.

## Primary route-axis outcomes

| Arm | Outcome | Mean net movement | 95% CI | Positive episodes | Sign-flip p |
| --- | --- | ---: | --- | ---: | ---: |
| Qwen primary | Later hidden state | 0.68747 | [0.68661, 0.68832] | 100.0% | 0.000010 |
| Qwen primary | Complete logit vector | 0.25833 | [0.25555, 0.26109] | 100.0% | 0.000010 |
| Mistral replication | Later hidden state | 0.80099 | [0.79955, 0.80245] | 100.0% | 0.000010 |
| Mistral replication | Complete logit vector | 0.05865 | [0.05681, 0.06056] | 100.0% | 0.000010 |
| DAX/WUG replication | Later hidden state | 0.60515 | [0.60352, 0.60679] | 100.0% | 0.000010 |
| DAX/WUG replication | Complete logit vector | 0.04717 | [0.04335, 0.05106] | 89.45% | 0.000010 |

Each value is cross-route projection minus the matched same-route donor control. A value of one corresponds to full movement along the episode's unpatched recipient-to-donor route axis.

## Bridge-path check

The bridge-masked to unmasked route-distance ratio was 0.000 in hidden-state space and 0.000 in full-logit space for every arm. The route difference therefore disappeared when later tokens could no longer attend to the route-dependent bridge positions.

## Cross-content route classification

Reference centroids used templates 0–2 in the opposite task-content mode. Evaluation used template 3.

| Arm | Unpatched route classification | Donor-route classification after interchange |
| --- | ---: | ---: |
| Qwen SAME/DIFFERENT | 83.50% | 75.59% |
| Mistral SAME/DIFFERENT | 91.99% | 79.88% |

These are supporting outcomes. Template 3 was held out from reference estimation. It had been examined during exploratory development and is not investigator-unseen wording.

## Answer endpoints

The answer endpoints were secondary.

| Arm | Mean signed margin movement | 90% CI | Mean two-token probability movement | 90% CI | Equivalence rule |
| --- | ---: | --- | ---: | --- | --- |
| Qwen primary | 0.45166 | [0.43629, 0.46694] | 0.00562 | [0.00467, 0.00658] | Failed |
| Mistral replication | 0.01162 | [0.01093, 0.01231] | 0.00232 | [0.00216, 0.00248] | Passed |
| DAX/WUG replication | -0.04874 | [-0.05872, -0.03870] | -0.01116 | [-0.01320, -0.00912] | Passed |

The Qwen primary margin movement exceeded the prespecified ±0.20-logit equivalence bound. Its two-token probability movement remained small. This endpoint does not establish a robust answer-choice effect because no choice-flip criterion was prespecified or passed.

## Engineering history

Confirmatory v1 stopped before scientific output because bare-label tokenisation failed on Mistral. Both Qwen v1 jobs were cancelled without reading their outputs.

Confirmatory v2 completed the Qwen primary and Mistral arms. Its DAX/WUG arm stopped on the first episode because the `X` candidate changed the query token boundary. The two completed scientific logs remained sealed. Tokenizer-only job `6a90c6fa984507d9db4e91a7` tested every answer label across both pinned tokenizers and all task conditions. The DAX/WUG query gained one newline after `Answer:`. The amended runner and fresh secondary seeds were frozen before any completed scientific output was opened.

The valid jobs are:

- Qwen primary: `6a90939f45686a1580c0f60e`;
- Mistral replication: `6a9093b3984507d9db4e8d7d`;
- amended Qwen DAX/WUG: `6a90c7e345686a1580c0fe2a`.

## Claim

Under the tested transformer architectures and tasks, acquisition route left a retained causal state in the bridge after the source-history prefix was neutralised. Interchanging that state changed the processing of a later event even though the current task relation was supplied again. The effect reached a fixed later hidden layer and the complete next-token logit distribution, transferred across task content and wording, replicated in Mistral, and replicated in a separate arbitrary-mapping task.

## Limits

The experiment does not test phenomenal experience and does not establish that either model is conscious. It does not establish the same mechanism in other architectures, unrestricted tasks, or long time intervals. The Qwen primary answer-margin result prevents a negligible-logit-margin claim. No robust overt-choice claim is made. The invalid verbal source-attribution measure remains excluded.
