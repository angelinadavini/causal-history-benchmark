# Confirmatory run log v2.1

## Frozen locks

- Base v2 manifest: `fb42c0f7e984c8e775b55960eb5c7f9be02d6eff8944bcdb198223435764a7d2`
- Secondary v2.1 manifest: `570f3119f16b32942c0bae5fdbdeb8396311a76c3bb8fed1b6eea577fc69cb54`
- Base protocol: `1fc2ff9ae7944fc426d57afee113531a92fa8ceed61c2a95d3dc47e8e082ad67`
- Base runner: `f2726b9c5486ec62791db3569e0e54c116aecd748ae54ce8335e1d81bf061ff7`
- Amendment protocol: `b05844cb4cb85a4c026217e9cec48448a794966857de87541b782fc6d8e31934`
- Secondary runner: `a4ed93c03cf2a4997c2f0da28f812f0f149fa6b0141a2134d0446bcba5a607fd`
- Joint analysis: `95d92f3e5c3764a98417e3e54d5d57eba3e76e8fa8b4331ad6e836aaabcb4849`

## Valid jobs

| Arm | Job ID | Terminal state |
| --- | --- | --- |
| Qwen primary SAME/DIFFERENT | `6a90939f45686a1580c0f60e` | Completed |
| Mistral SAME/DIFFERENT | `6a9093b3984507d9db4e8d7d` | Completed |
| Qwen DAX/WUG v2.1 | `6a90c7e345686a1580c0fe2a` | Completed |

## Invalid engineering jobs

- v1 Mistral `6a90910745686a1580c0f5c7`: bare-label tokenisation failure before episodes;
- v1 Qwen primary `6a9090f5984507d9db4e8d4a`: cancelled without reading output;
- v1 Qwen secondary `6a9090e2984507d9db4e8d48`: cancelled without reading output;
- v2 Qwen secondary `6a90938c45686a1580c0f60c`: contextual `X` boundary failure on the first episode.

## Integrity

All three valid final logs contained a complete compressed episode bundle and repeated run metadata. The frozen joint analysis recovered 512 Qwen primary episodes, 256 Mistral episodes, and 256 amended DAX/WUG episodes. Metadata locks matched the frozen manifests, protocols, and runners before outcome computation.

## Decision flags

- Qwen primary causal route-axis prediction: passed;
- Mistral cross-model replication: passed;
- DAX/WUG secondary-task replication: passed;
- bridge-path necessity check: passed in every arm;
- answer-endpoint equivalence: failed for Qwen primary, passed for Mistral and DAX/WUG.
