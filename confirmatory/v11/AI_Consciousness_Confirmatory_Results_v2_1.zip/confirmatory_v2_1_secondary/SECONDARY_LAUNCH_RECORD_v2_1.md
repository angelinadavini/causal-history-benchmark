# Confirmatory secondary launch record v2.1

Date: 28 August 2026

The amended DAX/WUG arm was submitted without opening the completed Qwen primary or Mistral replication outputs.

| Arm | Job ID | Hardware | Timeout |
| --- | --- | --- | --- |
| Qwen DAX/WUG secondary | `6a90c7e345686a1580c0fe2a` | T4 small | 35 minutes |

Frozen locks:

- base v2 manifest: `fb42c0f7e984c8e775b55960eb5c7f9be02d6eff8944bcdb198223435764a7d2`;
- secondary v2.1 manifest: `570f3119f16b32942c0bae5fdbdeb8396311a76c3bb8fed1b6eea577fc69cb54`;
- amendment protocol: `b05844cb4cb85a4c026217e9cec48448a794966857de87541b782fc6d8e31934`;
- secondary runner: `a4ed93c03cf2a4997c2f0da28f812f0f149fa6b0141a2134d0446bcba5a607fd`;
- joint analysis: `95d92f3e5c3764a98417e3e54d5d57eba3e76e8fa8b4331ad6e836aaabcb4849`.

The launch response contained no scientific output. Joint analysis remains blocked until the amended secondary job completes.
