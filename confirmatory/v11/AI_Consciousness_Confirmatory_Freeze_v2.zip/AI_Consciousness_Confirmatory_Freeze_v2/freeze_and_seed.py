#!/usr/bin/env python3
"""Hash the frozen package, then create the one confirmatory seed manifest."""

from __future__ import annotations

import hashlib
import json
import secrets
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
FILES = {
    "protocol_sha256": ROOT / "CONFIRMATORY_PROTOCOL_v2.md",
    "runner_sha256": ROOT / "confirmatory_runner.py",
    "analysis_sha256": ROOT / "analyse_confirmatory.py",
    "requirements_sha256": ROOT / "requirements-confirmatory.txt",
}
ARMS = ("qwen_primary", "mistral_replication", "qwen_secondary")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_bytes(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")


def main() -> None:
    output = ROOT / "CONFIRMATORY_SEED_MANIFEST_v2.json"
    if output.exists():
        raise RuntimeError(f"refusing to replace existing seed manifest: {output}")

    payload = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "entropy_source": "Python secrets.randbits using operating-system entropy",
        **{field: sha256(path) for field, path in FILES.items()},
        "arms": {
            arm: {
                "episode_seed": secrets.randbits(63),
                "reference_seed": secrets.randbits(63),
                "bootstrap_seed": secrets.randbits(63),
                "randomisation_seed": secrets.randbits(63),
            }
            for arm in ARMS
        },
    }
    payload["manifest_sha256"] = hashlib.sha256(canonical_bytes(payload)).hexdigest()
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(output)
    print(json.dumps({key: payload[key] for key in FILES}, indent=2, sort_keys=True))
    print("manifest_sha256", payload["manifest_sha256"])


if __name__ == "__main__":
    main()
