# Confirmatory v1 invalid launch record

Date: 27 August 2026

The three arms were submitted together from seed-manifest lock `77e262edecd9a7eb8da505e0a99e501e23ad2ca96f46998ce10e1c5495d3b380`. No confirmatory result was inspected between submissions.

| Arm | Job ID | Hardware | Timeout |
| --- | --- | --- | --- |
| Qwen primary SAME/DIFFERENT | `6a9090f5984507d9db4e8d4a` | T4 small | 45 minutes |
| Mistral cross-model SAME/DIFFERENT | `6a90910745686a1580c0f5c7` | A10G small | 75 minutes |
| Qwen secondary DAX/WUG | `6a9090e2984507d9db4e8d48` | T4 small | 35 minutes |

Frozen hashes recorded in the seed manifest:

- protocol: `4deb49e3c07f726d5b2df82d6c9b4d7d2abb2c6441dea9e74ecad95329d186d8`
- runner: `fea454d8c2991a5ddda740d7239f3c8fb7d038a47804ca07cd6bf073b5612710`
- analysis: `9b054115ce9d277d06d497827c00da5193d3a2dc131d86d93b85c00c4d7da6e5`
- requirements: `5fd7fcfeece3486c2137b6432c9d20c185cb211ec56afbe21eca9dbc5e986133`

The Mistral arm failed before episode generation because the runner tested bare answer-label tokenization. Both Qwen jobs were then cancelled without reading their logs or results. Version 1 has no scientific outcome and is not analysed as a null.
