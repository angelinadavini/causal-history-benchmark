# Confirmatory package v2

This package freezes the repaired confirmatory test of acquisition-history effects in a genuinely later machine event. Version 1 produced no scientific result; its tokenizer failure and cancelled jobs remain documented here.

Read in this order:

1. `CONFIRMATORY_PROTOCOL_v2.md`
2. `confirmatory_runner.py`
3. `analyse_confirmatory.py`
4. `requirements-confirmatory.txt`
5. `PREFLIGHT_RECORD_v2.md`
6. `CONFIRMATORY_V1_INVALIDATION.md`
7. `CONFIRMATORY_SEED_MANIFEST_v2.json` after it has been generated

`freeze_and_seed.py` creates the seed manifest only once. It refuses to replace an existing manifest.

The three fixed arms are:

- `qwen_primary`
- `mistral_replication`
- `qwen_secondary`

All scientific output is printed between machine-readable line prefixes:

- `CONFIRMATORY_METADATA_JSON=`
- `CONFIRMATORY_EPISODE_JSON=`
- `CONFIRMATORY_RECORDS_CHUNK=`
- `CONFIRMATORY_SUMMARY_JSON=`

The source-attribution measure is absent by design. The confirmatory claim concerns route-dependent causal state in later hidden processing and the complete next-token distribution. It does not establish consciousness.
