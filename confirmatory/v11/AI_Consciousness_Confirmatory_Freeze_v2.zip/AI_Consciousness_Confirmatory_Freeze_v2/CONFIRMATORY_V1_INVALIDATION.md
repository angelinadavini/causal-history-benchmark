# Confirmatory version 1 invalidation

Date: 27 August 2026

## Status

Confirmatory version 1 is invalid for scientific inference. It produced no inspected scientific result.

## Trigger

Mistral job `6a90910745686a1580c0f5c7` stopped during experiment construction. The runner encoded the bare label `0` and required a single token. At the pinned Mistral tokenizer revision, bare `0` encoded as `[29473, 29502]`. No acquisition-route episode ran before the exception.

## Contamination control

The paired Qwen jobs were cancelled immediately:

- primary job `6a9090f5984507d9db4e8d4a`;
- secondary-task job `6a9090e2984507d9db4e8d48`.

Their logs and scientific outputs were not read. The version 1 seeds will never be reused.

## Repair boundary

Tokenizer preflight job `6a90922a984507d9db4e8d65` established that the full query tokens are an exact prefix of both query-plus-answer candidates for both pinned models. Each contextual answer suffix is one token. Version 2 computes answer candidates from these contextual suffixes.

The version 2 repair also packages the complete episode table into the final log lines so that the prespecified analysis can recover every record. No model output informed either repair. All scientific choices from version 1 remain fixed.
