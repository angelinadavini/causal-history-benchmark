# Confirmatory preflight record v2

Date: 27 August 2026

## Model revision resolution

Job `6a908cb145686a1580c0f528` resolved the public model revisions before seed generation:

- Qwen2.5-3B-Instruct: `aa8e72537993ba99e69dfaafa59ed015b17504d1`
- Mistral-7B-Instruct-v0.3: `c170c708c41dac9275d15a8fff4eca08d52bab71`

## Tokenizer check

Jobs `6a908cf4984507d9db4e8d0f` and `6a908d18984507d9db4e8d13` used Transformers 5.13.0 and SentencePiece 0.2.1.

For `History processed. Ready.\n`:

- Qwen: 5 tokens, IDs `[13424, 15233, 13, 30982, 624]`
- Mistral: 7 tokens, IDs `[7634, 17012, 29491, 5707, 29492, 29491, 781]`

## Package-pin check

Job `6a908e6945686a1580c0f569` confirmed that these exact packages resolve together:

- Transformers 5.13.0
- SentencePiece 0.2.1
- Accelerate 1.10.1

## Mistral float16 cache check

The L4 preflight `6a908eda984507d9db4e8d27` was cancelled while waiting for hardware. It produced no model output.

Job `6a908f2e984507d9db4e8d2e` completed on A10G small using the pinned Mistral revision and float16:

- bridge tokens: 7;
- cache layers: 32;
- fixed hidden-state index 7 returned shape `[1, 40, 4096]`;
- later logits returned shape `[1, 40, 32768]`;
- logits were finite.

This was a neutral engineering check. It contained one neutral history and one later query. It did not compare acquisition routes or generate a scientific result.

## Contextual answer-token check

Confirmatory version 1 exposed an engineering error before scientific output: the runner required each bare answer label to encode as one token. Job `6a90910745686a1580c0f5c7` stopped while constructing the Mistral experiment because bare `0` encoded as two tokens. The paired Qwen jobs were cancelled without reading their logs or results.

Neutral tokenizer job `6a90922a984507d9db4e8d65` then encoded each complete later query and each query-plus-answer string at the pinned revisions:

- Qwen: the query token sequence remained an exact prefix; contextual suffix `0` was `[15]` and suffix `1` was `[16]`.
- Mistral: the query token sequence remained an exact prefix; contextual suffix `0` was `[29502]` and suffix `1` was `[29508]`.

Version 2 therefore resolves candidate answers from the contextual suffix after the exact query prefix. The answer margin is scored at the first suffix token that distinguishes the complete candidate strings. This check contained no acquisition-route comparison and generated no scientific result.

## Complete-record recovery check

The version 2 runner emits all episode records twice: individual JSON lines during execution and a compressed, base64-encoded bundle split across at most 16 final log lines. The analysis prefers the complete bundle when it is present. A deterministic synthetic round trip verifies that every record and numeric value is recovered exactly.
