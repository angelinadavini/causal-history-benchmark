#!/usr/bin/env python3
"""Frozen confirmatory runner for acquisition-history causal-state tests.

The script runs one prespecified arm and prints complete per-episode records as
single-line JSON. It never generates its own scientific seeds.
"""

from __future__ import annotations

import argparse
import base64
import gzip
import json
import math
import os
import platform
import random
import sys
from pathlib import Path

import torch
import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer, DynamicCache


BRIDGE_TEXT = "History processed. Ready.\n"
NEUTRAL_WORDS = "cloud stone window copper river lamp paper chair"

MODEL_SPECS = {
    "qwen_primary": {
        "repo": "Qwen/Qwen2.5-3B-Instruct",
        "revision": "aa8e72537993ba99e69dfaafa59ed015b17504d1",
        "task": "same_different",
        "patched_layers": list(range(6)),
        "outcome_layer": 8,
        "episodes": 512,
        "reference_reps": 16,
    },
    "mistral_replication": {
        "repo": "mistralai/Mistral-7B-Instruct-v0.3",
        "revision": "c170c708c41dac9275d15a8fff4eca08d52bab71",
        "task": "same_different",
        "patched_layers": list(range(5)),
        "outcome_layer": 7,
        "episodes": 256,
        "reference_reps": 16,
    },
    "qwen_secondary": {
        "repo": "Qwen/Qwen2.5-3B-Instruct",
        "revision": "aa8e72537993ba99e69dfaafa59ed015b17504d1",
        "task": "dax_wug",
        "patched_layers": list(range(6)),
        "outcome_layer": 8,
        "episodes": 256,
        "reference_reps": 0,
    },
}

SAME_EXAMPLES = [
    lambda m, n: f"Session {n}. Examples: "
    + ("0 -> 0; 1 -> 1; 0 -> 0; 1 -> 1." if m == 0 else "0 -> 1; 1 -> 0; 0 -> 1; 1 -> 0.")
    + "\n",
    lambda m, n: f"Session {n}. Observed cases: "
    + (
        "when 0 then 0; when 1 then 1; again 0 then 0; again 1 then 1."
        if m == 0
        else "when 0 then 1; when 1 then 0; again 0 then 1; again 1 then 0."
    )
    + "\n",
    lambda m, n: f"Session {n}. Training pairs: "
    + (
        "input 0 output 0 | input 1 output 1 | input 0 output 0 | input 1 output 1."
        if m == 0
        else "input 0 output 1 | input 1 output 0 | input 0 output 1 | input 1 output 0."
    )
    + "\n",
    lambda m, n: f"Session {n}. Demonstrations: "
    + ("0 gives 0, 1 gives 1, 0 gives 0, 1 gives 1." if m == 0 else "0 gives 1, 1 gives 0, 0 gives 1, 1 gives 0.")
    + "\n",
]

SAME_DIRECT = [
    lambda m, n: f"Session {n}. The instruction was supplied directly: {'SAME' if m == 0 else 'DIFFERENT'}.\n",
    lambda m, n: f"Session {n}. Direct rule: {'SAME' if m == 0 else 'DIFFERENT'}.\n",
    lambda m, n: f"Session {n}. You were told the rule explicitly: {'SAME' if m == 0 else 'DIFFERENT'}.\n",
    lambda m, n: f"Session {n}. Stated instruction: {'SAME' if m == 0 else 'DIFFERENT'}.\n",
]

DAX_NAMES = ["mira", "tovan", "selo", "pira", "navi", "lumo", "keta", "vori", "zema", "riko", "fena", "daro"]


def dax_examples(mode: int, nonce: str, template: int) -> str:
    a, b = ("X", "Y") if mode == 0 else ("Y", "X")
    pairs = [("mira", "DAX", a), ("tovan", "WUG", b), ("selo", "DAX", a), ("pira", "WUG", b)]
    if template == 0:
        return f"Session {nonce}. Examples: " + "; ".join(f"{x}: {v} -> {y}" for x, v, y in pairs) + ".\n"
    if template == 1:
        return f"Session {nonce}. Observed labels: " + " | ".join(f"{x} has {v} and answer {y}" for x, v, y in pairs) + ".\n"
    if template == 2:
        return f"Session {nonce}. Training cases: " + "; ".join(f"for {x}, {v} yields {y}" for x, v, y in pairs) + ".\n"
    return f"Session {nonce}. Demonstrations: " + "; ".join(f"{x} with {v} gives {y}" for x, v, y in pairs) + ".\n"


def dax_direct(mode: int, nonce: str, template: int) -> str:
    a, b = ("X", "Y") if mode == 0 else ("Y", "X")
    forms = [
        f"Mapping: DAX -> {a}; WUG -> {b}.",
        f"Direct mapping: DAX means {a}; WUG means {b}.",
        f"You were told: DAX is answered {a}, and WUG is answered {b}.",
        f"Stated mapping: answer {a} for DAX and {b} for WUG.",
    ]
    return f"Session {nonce}. {forms[template]}\n"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", choices=sorted(MODEL_SPECS), required=True)
    parser.add_argument("--seed-manifest", type=Path)
    return parser.parse_args()


def nonce(rng: random.Random) -> str:
    return " ".join(str(rng.randrange(10)) for _ in range(4))


def clone_cache(cache: DynamicCache) -> DynamicCache:
    cloned = DynamicCache()
    for layer_index, layer in enumerate(cache.layers):
        cloned.update(layer.keys.clone(), layer.values.clone(), layer_index)
    return cloned


def projection(base: torch.Tensor, moved: torch.Tensor, target: torch.Tensor) -> float:
    direction = target - base
    denominator = float(torch.dot(direction, direction))
    if not math.isfinite(denominator) or denominator <= 1e-12:
        raise RuntimeError("route axis has zero or non-finite length")
    return float(torch.dot(moved - base, direction) / denominator)


def distance(a: torch.Tensor, b: torch.Tensor) -> float:
    value = float(torch.norm(b - a))
    if not math.isfinite(value):
        raise RuntimeError("non-finite route distance")
    return value


class Experiment:
    def __init__(self, arm: str, seeds: dict[str, int]):
        self.arm = arm
        self.spec = MODEL_SPECS[arm]
        self.task = self.spec["task"]
        self.episode_rng = random.Random(int(seeds["episode_seed"]))
        self.reference_rng = random.Random(int(seeds["reference_seed"]))

        self.tokenizer = AutoTokenizer.from_pretrained(
            self.spec["repo"], revision=self.spec["revision"]
        )
        load_kwargs = {
            "revision": self.spec["revision"],
            "dtype": torch.float16,
            "attn_implementation": "sdpa",
            "low_cpu_mem_usage": True,
        }
        if arm == "mistral_replication":
            load_kwargs["device_map"] = "cuda"
            self.model = AutoModelForCausalLM.from_pretrained(self.spec["repo"], **load_kwargs).eval()
        else:
            self.model = AutoModelForCausalLM.from_pretrained(self.spec["repo"], **load_kwargs).cuda().eval()

        self.pad_id = self.tokenizer.eos_token_id
        self.bridge_ids = self.tokenizer.encode(BRIDGE_TEXT, add_special_tokens=False)
        self.max_history = self._max_history_tokens()
        self.end = self.max_history + len(self.bridge_ids)

    def _history_text(self, route: str, mode: int, session: str, template: int) -> str:
        if self.task == "same_different":
            templates = SAME_EXAMPLES if route == "examples" else SAME_DIRECT
            return templates[template](mode, session)
        return dax_examples(mode, session, template) if route == "examples" else dax_direct(mode, session, template)

    def _neutral_text(self, session: str) -> str:
        return f"Session {session}. Earlier material was neutral: {NEUTRAL_WORDS}.\n"

    def _max_history_tokens(self) -> int:
        probe = "0 0 0 0"
        lengths = [len(self.tokenizer.encode(self._neutral_text(probe), add_special_tokens=False))]
        for mode in (0, 1):
            for template in range(4):
                for route in ("examples", "explicit"):
                    lengths.append(
                        len(
                            self.tokenizer.encode(
                                self._history_text(route, mode, probe, template),
                                add_special_tokens=False,
                            )
                        )
                    )
        return max(lengths)

    def _cache_text(self, text: str) -> DynamicCache:
        history_ids = self.tokenizer.encode(text, add_special_tokens=False)
        filler = [self.pad_id] * (self.max_history - len(history_ids))
        input_ids = history_ids + filler + self.bridge_ids
        attention = [1] * len(history_ids) + [0] * len(filler) + [1] * len(self.bridge_ids)
        with torch.inference_mode():
            output = self.model(
                input_ids=torch.tensor([input_ids], device="cuda"),
                attention_mask=torch.tensor([attention], device="cuda"),
                use_cache=True,
                return_dict=True,
            )
        return output.past_key_values

    def route_cache(self, route: str, mode: int, session: str, template: int = 3) -> DynamicCache:
        route_cache = self._cache_text(self._history_text(route, mode, session, template))
        neutral_cache = self._cache_text(self._neutral_text(session))
        result = DynamicCache()
        for layer_index, (route_layer, neutral_layer) in enumerate(
            zip(route_cache.layers, neutral_cache.layers)
        ):
            keys = torch.cat(
                [
                    neutral_layer.keys[:, :, : self.max_history, :],
                    route_layer.keys[:, :, self.max_history : self.end, :],
                ],
                dim=2,
            ).clone()
            values = torch.cat(
                [
                    neutral_layer.values[:, :, : self.max_history, :],
                    route_layer.values[:, :, self.max_history : self.end, :],
                ],
                dim=2,
            ).clone()
            result.update(keys, values, layer_index)
        return result

    def patch(self, recipient: DynamicCache, donor: DynamicCache) -> DynamicCache:
        selected = set(self.spec["patched_layers"])
        result = DynamicCache()
        for layer_index, (recipient_layer, donor_layer) in enumerate(
            zip(recipient.layers, donor.layers)
        ):
            keys = recipient_layer.keys.clone()
            values = recipient_layer.values.clone()
            if layer_index in selected:
                keys[:, :, self.max_history : self.end, :] = donor_layer.keys[
                    :, :, self.max_history : self.end, :
                ]
                values[:, :, self.max_history : self.end, :] = donor_layer.values[
                    :, :, self.max_history : self.end, :
                ]
            result.update(keys, values, layer_index)
        return result

    def _query(self, mode: int, event: int, name: str | None) -> tuple[str, str, str]:
        if self.task == "same_different":
            rule = "SAME" if mode == 0 else "DIFFERENT"
            correct = str(event if mode == 0 else 1 - event)
            incorrect = "1" if correct == "0" else "0"
            text = (
                f"Current instruction: {rule}. New bit: {event}. "
                f"SAME means answer {event}. DIFFERENT means answer {1-event}. "
                "Reply only 0 or 1.\nAnswer:"
            )
            return text, correct, incorrect
        a, b = ("X", "Y") if mode == 0 else ("Y", "X")
        value = "DAX" if event == 0 else "WUG"
        correct = a if value == "DAX" else b
        incorrect = "Y" if correct == "X" else "X"
        text = (
            f"Current mapping: DAX -> {a}; WUG -> {b}. New item: {name} has {value}. "
            "Reply only X or Y.\nAnswer:"
        )
        return text, correct, incorrect

    def later(
        self,
        cache: DynamicCache,
        mode: int,
        event: int,
        name: str | None,
        bridge_visible: bool = True,
    ) -> dict[str, torch.Tensor | float]:
        query, correct, incorrect = self._query(mode, event, name)
        query_ids = self.tokenizer.encode(query, add_special_tokens=False)
        correct_full = self.tokenizer.encode(query + correct, add_special_tokens=False)
        incorrect_full = self.tokenizer.encode(query + incorrect, add_special_tokens=False)
        if correct_full[: len(query_ids)] != query_ids or incorrect_full[: len(query_ids)] != query_ids:
            raise RuntimeError("answer tokenization changed the query prefix")
        correct_ids = correct_full[len(query_ids) :]
        incorrect_ids = incorrect_full[len(query_ids) :]
        if not correct_ids or not incorrect_ids:
            raise RuntimeError("answer suffix has no tokens")
        positions = torch.arange(self.end, self.end + len(query_ids), device="cuda")
        attention = torch.ones((1, self.end + len(query_ids)), dtype=torch.long, device="cuda")
        if not bridge_visible:
            attention[:, self.max_history : self.end] = 0
        with torch.inference_mode():
            output = self.model(
                input_ids=torch.tensor([query_ids], device="cuda"),
                past_key_values=clone_cache(cache),
                attention_mask=attention,
                position_ids=positions.unsqueeze(0),
                cache_position=positions,
                use_cache=False,
                output_hidden_states=True,
                return_dict=True,
            )
        logits = output.logits[0, -1].float().cpu()
        hidden = output.hidden_states[self.spec["outcome_layer"]][0, -1].float().cpu()
        shared = 0
        while (
            shared < min(len(correct_ids), len(incorrect_ids))
            and correct_ids[shared] == incorrect_ids[shared]
        ):
            shared += 1
        if shared == 0:
            scoring_logits = logits
        else:
            scoring_ids = query_ids + correct_ids[:shared]
            scoring_positions = torch.arange(
                self.end, self.end + len(scoring_ids), device="cuda"
            )
            scoring_attention = torch.ones(
                (1, self.end + len(scoring_ids)), dtype=torch.long, device="cuda"
            )
            if not bridge_visible:
                scoring_attention[:, self.max_history : self.end] = 0
            with torch.inference_mode():
                scoring_output = self.model(
                    input_ids=torch.tensor([scoring_ids], device="cuda"),
                    past_key_values=clone_cache(cache),
                    attention_mask=scoring_attention,
                    position_ids=scoring_positions.unsqueeze(0),
                    cache_position=scoring_positions,
                    use_cache=False,
                    return_dict=True,
                )
            scoring_logits = scoring_output.logits[0, -1].float().cpu()
        correct_logit = scoring_logits[correct_ids[shared]]
        incorrect_logit = scoring_logits[incorrect_ids[shared]]
        margin = float(correct_logit - incorrect_logit)
        probability = float(torch.softmax(torch.stack([correct_logit, incorrect_logit]), dim=0)[0])
        return {"hidden": hidden, "logits": logits, "margin": margin, "probability": probability}

    def reference_centroids(self) -> dict | None:
        if self.task != "same_different":
            return None
        bank = {
            (mode, event, route): []
            for mode in (0, 1)
            for event in (0, 1)
            for route in ("examples", "explicit")
        }
        for mode in (0, 1):
            for template in (0, 1, 2):
                for _ in range(self.spec["reference_reps"]):
                    session = nonce(self.reference_rng)
                    for route in ("examples", "explicit"):
                        cache = self.route_cache(route, mode, session, template)
                        for event in (0, 1):
                            bank[(mode, event, route)].append(
                                self.later(cache, mode, event, None)["hidden"]
                            )
        return {key: torch.stack(values).mean(0) for key, values in bank.items()}

    @staticmethod
    def classify(vector: torch.Tensor, examples: torch.Tensor, explicit: torch.Tensor) -> str:
        return "examples" if float(torch.norm(vector - examples)) < float(torch.norm(vector - explicit)) else "explicit"

    def episode(
        self,
        episode_id: int,
        mode: int,
        event: int,
        centroids: dict | None,
    ) -> dict:
        first = nonce(self.episode_rng)
        second = nonce(self.episode_rng)
        while second == first:
            second = nonce(self.episode_rng)
        name = self.episode_rng.choice(DAX_NAMES) if self.task == "dax_wug" else None

        examples = self.route_cache("examples", mode, first)
        explicit = self.route_cache("explicit", mode, first)
        examples_control = self.route_cache("examples", mode, second)
        explicit_control = self.route_cache("explicit", mode, second)

        base_e = self.later(examples, mode, event, name)
        base_d = self.later(explicit, mode, event, name)
        cross_ed = self.later(self.patch(examples, explicit), mode, event, name)
        cross_de = self.later(self.patch(explicit, examples), mode, event, name)
        same_ee = self.later(self.patch(examples, examples_control), mode, event, name)
        same_dd = self.later(self.patch(explicit, explicit_control), mode, event, name)
        cut_e = self.later(examples, mode, event, name, bridge_visible=False)
        cut_d = self.later(explicit, mode, event, name, bridge_visible=False)

        hidden_cross = 0.5 * (
            projection(base_e["hidden"], cross_ed["hidden"], base_d["hidden"])
            + projection(base_d["hidden"], cross_de["hidden"], base_e["hidden"])
        )
        hidden_same = 0.5 * (
            projection(base_e["hidden"], same_ee["hidden"], base_d["hidden"])
            + projection(base_d["hidden"], same_dd["hidden"], base_e["hidden"])
        )
        logit_cross = 0.5 * (
            projection(base_e["logits"], cross_ed["logits"], base_d["logits"])
            + projection(base_d["logits"], cross_de["logits"], base_e["logits"])
        )
        logit_same = 0.5 * (
            projection(base_e["logits"], same_ee["logits"], base_d["logits"])
            + projection(base_d["logits"], same_dd["logits"], base_e["logits"])
        )

        margin_gap = base_d["margin"] - base_e["margin"]
        margin_sign = 0.0 if margin_gap == 0 else math.copysign(1.0, margin_gap)
        margin_move = 0.5 * (
            (cross_ed["margin"] - base_e["margin"]) * margin_sign
            + (cross_de["margin"] - base_d["margin"]) * -margin_sign
        )
        probability_gap = base_d["probability"] - base_e["probability"]
        probability_sign = 0.0 if probability_gap == 0 else math.copysign(1.0, probability_gap)
        probability_move = 0.5 * (
            (cross_ed["probability"] - base_e["probability"]) * probability_sign
            + (cross_de["probability"] - base_d["probability"]) * -probability_sign
        )

        result = {
            "arm": self.arm,
            "episode_id": episode_id,
            "mode": mode,
            "event": event,
            "name": name,
            "template": 3,
            "hidden_cross": hidden_cross,
            "hidden_same": hidden_same,
            "net_hidden": hidden_cross - hidden_same,
            "logit_cross": logit_cross,
            "logit_same": logit_same,
            "net_logit": logit_cross - logit_same,
            "hidden_route_distance": distance(base_e["hidden"], base_d["hidden"]),
            "hidden_cut_distance": distance(cut_e["hidden"], cut_d["hidden"]),
            "logit_route_distance": distance(base_e["logits"], base_d["logits"]),
            "logit_cut_distance": distance(cut_e["logits"], cut_d["logits"]),
            "margin_examples": base_e["margin"],
            "margin_explicit": base_d["margin"],
            "margin_move_toward_donor": margin_move,
            "probability_examples": base_e["probability"],
            "probability_explicit": base_d["probability"],
            "probability_move_toward_donor": probability_move,
        }

        if centroids is not None:
            reference_mode = 1 - mode
            ce = centroids[(reference_mode, event, "examples")]
            cd = centroids[(reference_mode, event, "explicit")]
            result["cross_content_baseline_accuracy"] = 0.5 * (
                (self.classify(base_e["hidden"], ce, cd) == "examples")
                + (self.classify(base_d["hidden"], ce, cd) == "explicit")
            )
            result["cross_content_donor_accuracy"] = 0.5 * (
                (self.classify(cross_ed["hidden"], ce, cd) == "explicit")
                + (self.classify(cross_de["hidden"], ce, cd) == "examples")
            )
        return result


def main() -> None:
    args = parse_args()
    if args.seed_manifest is not None:
        manifest_text = args.seed_manifest.read_text(encoding="utf-8")
    else:
        manifest_text = os.environ.get("SEED_MANIFEST_JSON", "")
    if not manifest_text:
        raise RuntimeError("seed manifest was not supplied")
    manifest = json.loads(manifest_text)
    if args.arm not in manifest["arms"]:
        raise RuntimeError(f"seed manifest has no arm {args.arm}")
    seeds = manifest["arms"][args.arm]
    experiment = Experiment(args.arm, seeds)
    spec = MODEL_SPECS[args.arm]

    metadata = {
        "arm": args.arm,
        "model": spec["repo"],
        "revision": spec["revision"],
        "task": spec["task"],
        "episodes": spec["episodes"],
        "patched_layers": spec["patched_layers"],
        "outcome_layer": spec["outcome_layer"],
        "bridge_text": BRIDGE_TEXT,
        "bridge_token_ids": experiment.bridge_ids,
        "bridge_token_count": len(experiment.bridge_ids),
        "max_history_tokens": experiment.max_history,
        "answer_margin_definition": "logit difference at the first contextual suffix token that distinguishes the two complete answer strings",
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "python": sys.version,
        "platform": platform.platform(),
        "cuda": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(0),
        "seed_manifest_sha256": manifest["manifest_sha256"],
        "protocol_sha256": manifest["protocol_sha256"],
        "runner_sha256": manifest["runner_sha256"],
    }
    print("CONFIRMATORY_METADATA_JSON=" + json.dumps(metadata, sort_keys=True), flush=True)

    centroids = experiment.reference_centroids()
    per_cell = spec["episodes"] // 4
    if per_cell * 4 != spec["episodes"]:
        raise RuntimeError("episode count is not divisible by four balanced cells")

    records = []
    episode_id = 0
    for mode in (0, 1):
        for event in (0, 1):
            for _ in range(per_cell):
                record = experiment.episode(episode_id, mode, event, centroids)
                records.append(record)
                print("CONFIRMATORY_EPISODE_JSON=" + json.dumps(record, sort_keys=True), flush=True)
                episode_id += 1

    print("CONFIRMATORY_METADATA_JSON=" + json.dumps(metadata, sort_keys=True), flush=True)
    packed = base64.b64encode(
        gzip.compress(
            json.dumps(records, sort_keys=True, separators=(",", ":")).encode("utf-8")
        )
    ).decode("ascii")
    chunk_size = 12_000
    chunks = [packed[start : start + chunk_size] for start in range(0, len(packed), chunk_size)]
    if len(chunks) > 16:
        raise RuntimeError(f"packed record bundle needs {len(chunks)} log chunks; maximum is 16")
    for index, chunk in enumerate(chunks, start=1):
        print(
            f"CONFIRMATORY_RECORDS_CHUNK={index}/{len(chunks)}:{chunk}",
            flush=True,
        )

    summary = {
        "arm": args.arm,
        "n": len(records),
        "mean_net_hidden": sum(r["net_hidden"] for r in records) / len(records),
        "mean_net_logit": sum(r["net_logit"] for r in records) / len(records),
        "mean_margin_move_toward_donor": sum(r["margin_move_toward_donor"] for r in records) / len(records),
        "mean_probability_move_toward_donor": sum(r["probability_move_toward_donor"] for r in records) / len(records),
    }
    if centroids is not None:
        summary["mean_cross_content_baseline_accuracy"] = sum(
            r["cross_content_baseline_accuracy"] for r in records
        ) / len(records)
        summary["mean_cross_content_donor_accuracy"] = sum(
            r["cross_content_donor_accuracy"] for r in records
        ) / len(records)
    print("CONFIRMATORY_SUMMARY_JSON=" + json.dumps(summary, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
